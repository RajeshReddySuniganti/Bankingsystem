  <?php
$server="sql211.epizy.com";
$user="epiz_29040960";
$password="u2GMJZeutRgw4RY";
$db="epiz_29040960_bankingsystem";
 $conn=mysqli_connect($server,$user,$password,$db);
          if($conn){
          	
          }
          else{
            echo "error";
          
        }
        ?>